import { useEffect, useMemo, useState } from "react";
import {
  Archive,
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  Clock3,
  Command,
  FileText,
  GripVertical,
  Inbox,
  LayoutDashboard,
  ListTodo,
  Mail,
  MessageSquareText,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  SlidersHorizontal,
  Sparkles,
  Target,
  TrendingUp,
  UserRound,
  WandSparkles,
  X,
  Zap,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";

type Status = "saved" | "applied" | "process" | "decision";
type NavPage = "Visão geral" | "Candidaturas" | "Tarefas" | "Currículos";

type Job = {
  id: number;
  company: string;
  initials: string;
  role: string;
  location: string;
  source: string;
  fit: number;
  status: Status;
  next: string;
  tone: string;
  note: string;
};

type Task = {
  id: number;
  title: string;
  company: string;
  due: string;
  kind: "urgent" | "soon" | "scheduled";
  done: boolean;
};

const initialJobs: Job[] = [
  {
    id: 1,
    company: "Nubank",
    initials: "Nu",
    role: "Engineering Manager",
    location: "São Paulo · Híbrido",
    source: "LinkedIn",
    fit: 94,
    status: "saved",
    next: "Salva hoje",
    tone: "violet",
    note: "Sua experiência liderando times de plataforma cobre 8 de 9 requisitos.",
  },
  {
    id: 2,
    company: "Alice",
    initials: "A",
    role: "Head of Technology",
    location: "São Paulo · Presencial",
    source: "Gupy",
    fit: 87,
    status: "saved",
    next: "Salva ontem",
    tone: "coral",
    note: "Boa aderência em liderança e transformação digital; atenção ao modelo presencial.",
  },
  {
    id: 3,
    company: "Loft",
    initials: "L",
    role: "Gerente de Plataforma",
    location: "Remoto · Brasil",
    source: "InHire",
    fit: 82,
    status: "applied",
    next: "Enviada há 2 dias",
    tone: "blue",
    note: "CV Executivo/Híbrido enviado com 82% de cobertura ATS.",
  },
  {
    id: 4,
    company: "iFood",
    initials: "iF",
    role: "Tech Lead Manager",
    location: "Osasco · Híbrido",
    source: "Greenhouse",
    fit: 91,
    status: "applied",
    next: "Em análise há 4 dias",
    tone: "red",
    note: "Recebimento confirmado por e-mail. Nenhuma ação necessária agora.",
  },
  {
    id: 5,
    company: "QuintoAndar",
    initials: "Q",
    role: "Engineering Manager",
    location: "São Paulo · Híbrido",
    source: "Lever",
    fit: 89,
    status: "process",
    next: "Teste até amanhã",
    tone: "yellow",
    note: "Teste de liderança recebido por e-mail. Prazo detectado automaticamente.",
  },
  {
    id: 6,
    company: "Stone",
    initials: "S",
    role: "Diretora de Engenharia",
    location: "São Paulo · Híbrido",
    source: "Indicação",
    fit: 96,
    status: "process",
    next: "Entrevista · 24 out",
    tone: "green",
    note: "Entrevista com VP de Produto. Prepare histórias sobre escala e gestão de mudança.",
  },
  {
    id: 7,
    company: "Creditas",
    initials: "C",
    role: "Head de Operações Tech",
    location: "São Paulo · Híbrido",
    source: "LinkedIn",
    fit: 84,
    status: "decision",
    next: "Atualizada hoje",
    tone: "navy",
    note: "Processo encerrado após retorno do recrutador. Evidência salva no histórico.",
  },
];

const initialTasks: Task[] = [
  {
    id: 1,
    title: "Concluir teste de liderança",
    company: "QuintoAndar",
    due: "Amanhã, 23:59",
    kind: "urgent",
    done: false,
  },
  {
    id: 2,
    title: "Preparar entrevista com VP",
    company: "Stone",
    due: "24 out, 10:30",
    kind: "soon",
    done: false,
  },
  {
    id: 3,
    title: "Revisar resposta sobre Kubernetes",
    company: "Nubank",
    due: "Hoje",
    kind: "soon",
    done: false,
  },
  {
    id: 4,
    title: "Atualizar CV Executivo em inglês",
    company: "Perfil",
    due: "Esta semana",
    kind: "scheduled",
    done: false,
  },
];

const columns: { id: Status; label: string; description: string }[] = [
  { id: "saved", label: "Descobertas", description: "Para avaliar" },
  { id: "applied", label: "Candidatadas", description: "Enviadas e em análise" },
  { id: "process", label: "Em processo", description: "Exigem atenção" },
  { id: "decision", label: "Decisão", description: "Ciclo finalizado" },
];

const navItems: { label: NavPage; icon: typeof LayoutDashboard }[] = [
  { label: "Visão geral", icon: LayoutDashboard },
  { label: "Candidaturas", icon: BriefcaseBusiness },
  { label: "Tarefas", icon: ListTodo },
  { label: "Currículos", icon: FileText },
];

function IconButton({
  label,
  children,
  onClick,
  active = false,
}: {
  label: string;
  children: React.ReactNode;
  onClick?: () => void;
  active?: boolean;
}) {
  return (
    <button
      className={`icon-button ${active ? "is-active" : ""}`}
      aria-label={label}
      title={label}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

function JobCard({
  job,
  onOpen,
  onDragStart,
}: {
  job: Job;
  onOpen: () => void;
  onDragStart: () => void;
}) {
  return (
    <motion.article
      layout
      layoutId={`job-${job.id}`}
      className="job-card"
      draggable
      onDragStart={onDragStart}
      onClick={onOpen}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      whileHover={{ y: -3 }}
      transition={{ type: "spring", stiffness: 380, damping: 30 }}
      tabIndex={0}
      onKeyDown={(event) => event.key === "Enter" && onOpen()}
      aria-label={`Abrir candidatura ${job.role} na ${job.company}`}
    >
      <div className="job-card-top">
        <div className={`company-logo ${job.tone}`}>{job.initials}</div>
        <div className="fit-score" aria-label={`${job.fit}% de aderência`}>
          <span>{job.fit}%</span>
          <span className="fit-label">fit</span>
        </div>
      </div>
      <div className="job-copy">
        <p className="company-name">{job.company}</p>
        <h3>{job.role}</h3>
        <p className="job-location">{job.location}</p>
      </div>
      <div className="job-card-footer">
        <span className={job.status === "process" ? "next urgent" : "next"}>
          {job.status === "process" ? <Clock3 size={13} /> : <Mail size={13} />}
          {job.next}
        </span>
        <GripVertical className="drag-handle" size={17} aria-hidden="true" />
      </div>
    </motion.article>
  );
}

function TaskRow({
  task,
  onToggle,
}: {
  task: Task;
  onToggle: () => void;
}) {
  return (
    <motion.div
      layout
      className={`task-row ${task.done ? "is-done" : ""}`}
      initial={{ opacity: 0, x: 8 }}
      animate={{ opacity: 1, x: 0 }}
    >
      <button
        className={`task-check ${task.done ? "checked" : ""}`}
        onClick={onToggle}
        aria-label={task.done ? "Reabrir tarefa" : "Concluir tarefa"}
      >
        <Check size={14} strokeWidth={3} />
      </button>
      <div className="task-copy">
        <strong>{task.title}</strong>
        <span>{task.company}</span>
      </div>
      <span className={`task-due ${task.kind}`}>
        {task.kind === "urgent" && <CircleAlert size={13} />}
        {task.due}
      </span>
    </motion.div>
  );
}

export default function App() {
  const [jobs, setJobs] = useState(initialJobs);
  const [tasks, setTasks] = useState(initialTasks);
  const [activePage, setActivePage] = useState<NavPage>("Visão geral");
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [draggedJob, setDraggedJob] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [newJobUrl, setNewJobUrl] = useState("");
  const [toast, setToast] = useState("");

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setShowSearch(true);
      }
      if (event.key === "Escape") {
        setShowSearch(false);
        setSelectedJob(null);
        setShowAdd(false);
      }
    };
    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, []);

  const visibleJobs = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return jobs;
    return jobs.filter((job) =>
      `${job.company} ${job.role} ${job.location}`.toLowerCase().includes(query),
    );
  }, [jobs, search]);

  const openTasks = tasks.filter((task) => !task.done);

  const moveJob = (status: Status) => {
    if (!draggedJob) return;
    const moved = jobs.find((job) => job.id === draggedJob);
    if (!moved || moved.status === status) return;
    setJobs((current) =>
      current.map((job) =>
        job.id === draggedJob
          ? {
              ...job,
              status,
              next:
                status === "saved"
                  ? "Movida agora"
                  : status === "applied"
                    ? "Enviada agora"
                    : status === "process"
                      ? "Etapa atualizada"
                      : "Ciclo finalizado",
            }
          : job,
      ),
    );
    setToast(`${moved.company} movida para ${columns.find((column) => column.id === status)?.label}`);
    window.setTimeout(() => setToast(""), 2800);
  };

  const addJob = () => {
    if (!newJobUrl.trim()) return;
    const newJob: Job = {
      id: Date.now(),
      company: "Nova oportunidade",
      initials: "N",
      role: "Vaga em análise pela IA",
      location: "Detalhes sendo extraídos",
      source: "Link",
      fit: 78,
      status: "saved",
      next: "Adicionada agora",
      tone: "violet",
      note: "O VagaPilot está extraindo os requisitos e comparando com seus fatos confirmados.",
    };
    setJobs((current) => [newJob, ...current]);
    setShowAdd(false);
    setNewJobUrl("");
    setToast("Vaga adicionada ao pipeline");
    window.setTimeout(() => setToast(""), 2800);
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <Sparkles size={19} fill="currentColor" />
          </div>
          <span>VagaPilot</span>
        </div>

        <nav className="main-nav" aria-label="Navegação principal">
          <p className="nav-eyebrow">Workspace</p>
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                className={`nav-item ${activePage === item.label ? "active" : ""}`}
                onClick={() => setActivePage(item.label)}
              >
                <Icon size={19} />
                <span>{item.label}</span>
                {item.label === "Tarefas" && <span className="nav-count">{openTasks.length}</span>}
              </button>
            );
          })}
          <p className="nav-eyebrow nav-section">Assistente</p>
          <button className="nav-item" onClick={() => setShowAdd(true)}>
            <MessageSquareText size={19} />
            <span>Conversar com a IA</span>
          </button>
          <button className="nav-item">
            <Target size={19} />
            <span>Buscas salvas</span>
          </button>
        </nav>

        <div className="sidebar-bottom">
          <div className="plan-card">
            <div className="plan-icon">
              <Zap size={16} fill="currentColor" />
            </div>
            <div>
              <strong>Plano Pro</strong>
              <span>18 de 30 análises</span>
            </div>
            <div className="plan-progress">
              <span />
            </div>
          </div>
          <button className="profile-button">
            <div className="avatar">MA</div>
            <div>
              <strong>Marina Alves</strong>
              <span>Perfil 92% completo</span>
            </div>
            <MoreHorizontal size={18} />
          </button>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <p className="date-label">Segunda, 21 de outubro</p>
            <h1>
              Olá, Marina <span className="wave">—</span> vamos avançar?
            </h1>
          </div>
          <div className="topbar-actions">
            <AnimatePresence>
              {showSearch && (
                <motion.div
                  className="search-field"
                  initial={{ width: 40, opacity: 0 }}
                  animate={{ width: 230, opacity: 1 }}
                  exit={{ width: 40, opacity: 0 }}
                >
                  <Search size={17} />
                  <input
                    autoFocus
                    value={search}
                    onChange={(event) => setSearch(event.target.value)}
                    placeholder="Buscar candidatura..."
                    aria-label="Buscar candidatura"
                  />
                  <button
                    aria-label="Fechar busca"
                    onClick={() => {
                      setShowSearch(false);
                      setSearch("");
                    }}
                  >
                    <X size={15} />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
            {!showSearch && (
              <IconButton label="Buscar" onClick={() => setShowSearch(true)}>
                <Search size={19} />
              </IconButton>
            )}
            <IconButton label="Notificações">
              <Bell size={19} />
              <span className="notification-dot" />
            </IconButton>
            <button className="primary-button" onClick={() => setShowAdd(true)}>
              <Plus size={18} strokeWidth={2.5} />
              Analisar nova vaga
            </button>
          </div>
        </header>

        <section className="metrics-grid" aria-label="Resumo de desempenho">
          <article className="metric-card feature-metric">
            <div className="metric-head">
              <span className="metric-icon violet-icon">
                <BriefcaseBusiness size={18} />
              </span>
              <span className="trend positive">
                <TrendingUp size={13} /> 18%
              </span>
            </div>
            <div className="metric-value">24</div>
            <p>Candidaturas este mês</p>
            <div className="mini-chart" aria-hidden="true">
              {[20, 38, 31, 58, 48, 72, 66, 90, 82, 100].map((height, index) => (
                <span key={index} style={{ height: `${height}%` }} />
              ))}
            </div>
          </article>
          <article className="metric-card">
            <div className="metric-head">
              <span className="metric-icon green-icon">
                <Target size={18} />
              </span>
              <span className="trend positive">+6 pts</span>
            </div>
            <div className="metric-value">86%</div>
            <p>Fit médio das vagas</p>
            <div className="metric-progress">
              <span style={{ width: "86%" }} />
            </div>
          </article>
          <article className="metric-card">
            <div className="metric-head">
              <span className="metric-icon amber-icon">
                <Clock3 size={18} />
              </span>
              <span className="metric-note">Requer atenção</span>
            </div>
            <div className="metric-value">4</div>
            <p>Ações pendentes</p>
            <div className="metric-subline">
              <span className="alert-dot" /> 1 vence amanhã
            </div>
          </article>
          <article className="metric-card">
            <div className="metric-head">
              <span className="metric-icon blue-icon">
                <Inbox size={18} />
              </span>
              <span className="trend positive">+12%</span>
            </div>
            <div className="metric-value">42%</div>
            <p>Taxa de retorno</p>
            <div className="metric-subline muted">Acima da sua média de 36%</div>
          </article>
        </section>

        {activePage === "Tarefas" ? (
          <motion.section
            className="tasks-page"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="section-heading">
              <div>
                <h2>Suas ações</h2>
                <p>Prioridades identificadas nos seus processos e e-mails.</p>
              </div>
              <button className="secondary-button">
                <Plus size={17} /> Nova tarefa
              </button>
            </div>
            <div className="tasks-card expanded">
              {tasks.map((task) => (
                <TaskRow
                  key={task.id}
                  task={task}
                  onToggle={() =>
                    setTasks((current) =>
                      current.map((item) =>
                        item.id === task.id ? { ...item, done: !item.done } : item,
                      ),
                    )
                  }
                />
              ))}
            </div>
          </motion.section>
        ) : activePage === "Currículos" ? (
          <motion.section
            className="resume-page"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="section-heading">
              <div>
                <h2>Seus currículos</h2>
                <p>Versões por trilha, sempre apoiadas em fatos confirmados.</p>
              </div>
              <button className="secondary-button">
                <Plus size={17} /> Adicionar versão
              </button>
            </div>
            <div className="resume-grid">
              {[
                ["Executivo & Híbrido", "PT-BR", "Atualizado há 2 dias", "92%"],
                ["Gestão de Engenharia", "PT-BR", "Atualizado há 1 semana", "88%"],
                ["Engineering Leadership", "EN", "Revisão recomendada", "76%"],
              ].map(([name, language, updated, score]) => (
                <article className="resume-card" key={name}>
                  <div className="document-preview">
                    <FileText size={32} />
                    <span>{language}</span>
                  </div>
                  <div>
                    <h3>{name}</h3>
                    <p>{updated}</p>
                    <strong>{score} de completude</strong>
                  </div>
                  <ChevronRight size={19} />
                </article>
              ))}
            </div>
          </motion.section>
        ) : (
          <>
            <section className="workspace-header">
              <div>
                <div className="title-line">
                  <h2>Pipeline de candidaturas</h2>
                  <span className="live-badge">
                    <span /> Atualizado agora
                  </span>
                </div>
                <p>Arraste os cards entre as etapas para manter seu progresso em dia.</p>
              </div>
              <div className="workspace-actions">
                <button className="filter-button">
                  <SlidersHorizontal size={16} />
                  Filtros
                  <span className="filter-count">2</span>
                </button>
                <button className="filter-button">
                  Este mês <ChevronDown size={15} />
                </button>
              </div>
            </section>

            <div className="workspace-layout">
              <section className="kanban" aria-label="Kanban de candidaturas">
                {columns.map((column) => {
                  const columnJobs = visibleJobs.filter((job) => job.status === column.id);
                  return (
                    <div
                      className={`kanban-column column-${column.id}`}
                      key={column.id}
                      onDragOver={(event) => event.preventDefault()}
                      onDrop={() => moveJob(column.id)}
                    >
                      <div className="column-header">
                        <div>
                          <span className="column-dot" />
                          <h3>{column.label}</h3>
                          <span className="column-count">{columnJobs.length}</span>
                        </div>
                        <p>{column.description}</p>
                      </div>
                      <motion.div className="column-cards" layout>
                        <AnimatePresence mode="popLayout">
                          {columnJobs.map((job) => (
                            <JobCard
                              key={job.id}
                              job={job}
                              onDragStart={() => setDraggedJob(job.id)}
                              onOpen={() => setSelectedJob(job)}
                            />
                          ))}
                        </AnimatePresence>
                        {column.id === "saved" && (
                          <button className="add-card-button" onClick={() => setShowAdd(true)}>
                            <Plus size={16} /> Adicionar vaga
                          </button>
                        )}
                      </motion.div>
                    </div>
                  );
                })}
              </section>

              <aside className="right-rail">
                <section className="tasks-card">
                  <div className="rail-heading">
                    <div>
                      <ListTodo size={18} />
                      <h3>Próximas ações</h3>
                    </div>
                    <button onClick={() => setActivePage("Tarefas")}>Ver todas</button>
                  </div>
                  {openTasks.slice(0, 3).map((task) => (
                    <TaskRow
                      key={task.id}
                      task={task}
                      onToggle={() =>
                        setTasks((current) =>
                          current.map((item) =>
                            item.id === task.id ? { ...item, done: true } : item,
                          ),
                        )
                      }
                    />
                  ))}
                </section>

                <section className="insight-card">
                  <div className="insight-head">
                    <span>
                      <WandSparkles size={17} />
                    </span>
                    <p>Insight do VagaPilot</p>
                  </div>
                  <h3>Seu momento está forte.</h3>
                  <p>
                    Vagas com foco em <strong>liderança de plataforma</strong> têm gerado 2× mais
                    retornos no seu perfil.
                  </p>
                  <button>
                    Ver vagas semelhantes <ChevronRight size={15} />
                  </button>
                  <div className="insight-orbit" aria-hidden="true">
                    <Sparkles size={22} />
                  </div>
                </section>

                <section className="sync-card">
                  <div className="sync-icon">
                    <Mail size={17} />
                    <span />
                  </div>
                  <div>
                    <strong>Gmail sincronizado</strong>
                    <span>Última leitura há 2 min</span>
                  </div>
                  <CheckCircle2 size={18} className="sync-check" />
                </section>
              </aside>
            </div>
          </>
        )}
      </main>

      <AnimatePresence>
        {selectedJob && (
          <>
            <motion.button
              className="overlay"
              aria-label="Fechar detalhes"
              onClick={() => setSelectedJob(null)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.aside
              className="detail-drawer"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 34 }}
            >
              <div className="drawer-top">
                <span>Detalhes da candidatura</span>
                <IconButton label="Fechar" onClick={() => setSelectedJob(null)}>
                  <X size={19} />
                </IconButton>
              </div>
              <div className="drawer-company">
                <div className={`company-logo large ${selectedJob.tone}`}>
                  {selectedJob.initials}
                </div>
                <div>
                  <p>{selectedJob.company}</p>
                  <h2>{selectedJob.role}</h2>
                  <span>{selectedJob.location}</span>
                </div>
              </div>
              <div className="fit-panel">
                <div className="fit-ring">
                  <span>{selectedJob.fit}</span>
                  <small>fit</small>
                </div>
                <div>
                  <strong>Aderência {selectedJob.fit >= 90 ? "excelente" : "alta"}</strong>
                  <p>{selectedJob.note}</p>
                </div>
              </div>
              <div className="drawer-section">
                <p className="drawer-label">Próxima ação</p>
                <div className="action-callout">
                  <CalendarDays size={19} />
                  <div>
                    <strong>{selectedJob.next}</strong>
                    <span>O VagaPilot vai lembrar você no momento certo.</span>
                  </div>
                </div>
              </div>
              <div className="drawer-section">
                <p className="drawer-label">Linha do tempo</p>
                <div className="timeline">
                  <div>
                    <span />
                    <strong>Status atualizado</strong>
                    <p>Detectado automaticamente via {selectedJob.source}.</p>
                  </div>
                  <div>
                    <span />
                    <strong>Vaga analisada</strong>
                    <p>Fit calculado usando apenas fatos confirmados.</p>
                  </div>
                </div>
              </div>
              <div className="drawer-actions">
                <button className="secondary-button">
                  <Archive size={17} /> Arquivar
                </button>
                <button className="primary-button">
                  <Sparkles size={17} /> Preparar próxima etapa
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAdd && (
          <div className="modal-layer">
            <motion.button
              className="overlay modal-overlay"
              aria-label="Fechar modal"
              onClick={() => setShowAdd(false)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.section
              className="add-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="add-title"
              initial={{ opacity: 0, y: 18, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.98 }}
            >
              <div className="modal-icon">
                <Sparkles size={21} />
              </div>
              <h2 id="add-title">Vamos analisar uma nova vaga</h2>
              <p>
                Cole o link. Eu extraio os requisitos, verifico duplicidade e comparo com seus
                fatos confirmados.
              </p>
              <label className="url-field">
                <span>Link da vaga</span>
                <div>
                  <Search size={18} />
                  <input
                    autoFocus
                    value={newJobUrl}
                    onChange={(event) => setNewJobUrl(event.target.value)}
                    onKeyDown={(event) => event.key === "Enter" && addJob()}
                    placeholder="linkedin.com/jobs/view/..."
                  />
                </div>
              </label>
              <div className="modal-trust">
                <CheckCircle2 size={16} />
                Nada será enviado sem sua aprovação.
              </div>
              <div className="modal-actions">
                <button className="text-button" onClick={() => setShowAdd(false)}>
                  Agora não
                </button>
                <button className="primary-button" onClick={addJob} disabled={!newJobUrl.trim()}>
                  Analisar com IA <ChevronRight size={17} />
                </button>
              </div>
            </motion.section>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div
            className="toast"
            initial={{ opacity: 0, y: 16, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: 10, x: "-50%" }}
          >
            <CheckCircle2 size={18} />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="shortcut-hint">
        <Command size={13} /> K para buscar
      </div>
    </div>
  );
}
